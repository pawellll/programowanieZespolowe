var config = {};

config.dbAddress = 'localhost';

config.httpPort = 1335;

module.exports = config;
